import Callback from './callback';

interface CallbackTable {
  [index: string]: Callback[];
}

export default CallbackTable;
