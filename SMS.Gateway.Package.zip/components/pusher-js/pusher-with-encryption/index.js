module.exports = require('../dist/web/pusher-with-encryption');
